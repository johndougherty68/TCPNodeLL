// process.argv will print out any command line arguments.
console.log(process.argv);
